<?php

class UserConnectionFixture extends SocialiTestFixture {
	public $import = array('table' => 'user_connections');
}