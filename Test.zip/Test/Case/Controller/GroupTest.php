<?php

class GroupTest extends ControllerTestCase {
	
	public $fixtures = array('app.vendor', 'app.vendorManagement', 'app.vendorLogin', 'app.user', 'app.userGroup',
			'app.userGroupMapping', 'app.userImportedContact', 'app.userLoginData', 'app.userConnection', 
			'app.userInvite', 'app.emailQueue');
	public $autoFixtures = false;
	
	private $description = "";
	private $token = "";
	
	private function debug($request, $response) {
		$trace = debug_backtrace();
		$caller = $trace[1]["function"];
		echo("<h3>Test Case: $caller</h3>");
		if ($this->description) {
			echo "Description:";
			echo("<div style='color: #000;background: #f0f0f0;padding: 15px;-moz-box-shadow: 1px 1px 2px rgba(0, 0, 0, 0.3);-webkit-box-shadow: 1px 1px 2px rgba(0, 0, 0, 0.3);box-shadow: 1px 1px 2px rgba(0, 0, 0, 0.3);'>");
			echo($this->description . "</div>");
		}
		echo("Request:<br>");
		$header = "";
		if (array_key_exists('CONTENT_TYPE', $_SERVER)) {
			$header .= "\nContent-Type: " . $_SERVER['CONTENT_TYPE'];
		}
		if (array_key_exists('HTTP_ACCEPT', $_SERVER)) {
			$header .= "\nAccept: " . $_SERVER['HTTP_ACCEPT'];
		}
		pr("Action: " . $_SERVER['REQUEST_METHOD'] .
				"\nEndPoint: " . $this->controller->request->here . "$header");
		if ($request) {
			pr($request);
		}
		echo("Response:<br>");
		pr($response);
		echo("Status Code:<br>");
		pr($this->controller->response->statusCode());
		$this->description = "";
	}
	
	private function do_login() {
		$this->loadFixtures('Vendor', 'VendorManagement', 'VendorLogin', 'UserLoginData');
		$_SERVER['CONTENT_TYPE'] = 'application/json';
		$_SERVER['HTTP_ACCEPT'] = 'application/json';
		$data = '{"email": "email_2@gmail.com", "password": "password_2"}';
		$result = $this->testAction(
			'/v2/vendor/login',
			array (
					'return' => 'contents',
					'data' => $data,
					'method' => 'post'
			)
		);
		$this->controller->Session->destroy();
		$json = json_decode($result, true);
		if (array_key_exists("data", $json)) {
			$data = $json["data"];
			if (array_key_exists("token", $json["data"])) {
				$this->token = $json["data"]["token"];
			}
		}
		
		return $json;
	}
	
	private function addToken($url) {
		return $url . "?token=" . $this->token;
	}
	
	public function testAddPersonalGroup() {
		$this->description = "This test case validates the scenario when a user add a personal group.";
		$this->do_login();
		$this->loadFixtures('User', 'UserGroup', 'UserGroupMapping');
		$data = array('token' => $this->token, 'label' => 'Soccer Moms', 
				'group_type' => 1, 'description' => 'All soccer moms in McKinney');
		$json = json_encode($data);
		$result = $this->testAction(
				'/v2/groups',
				array(
						'return' => 'contents',
						'data' => $json,
						'method' => 'post'
				)
		);
		$this->debug($json, $result);
	}
	
	public function testAddSharedGroup() {
		$this->description = "This test case validates the scenario when a user add a shared group.";
		$this->do_login();
		$this->loadFixtures('User', 'UserGroup', 'UserGroupMapping');
		$data = array('token' => $this->token, 'label' => 'Soccer Moms',
				'group_type' => 2, 'description' => 'All soccer moms in McKinney');
		$json = json_encode($data);
		$result = $this->testAction(
				'/v2/groups',
				array(
						'return' => 'contents',
						'data' => $json,
						'method' => 'post'
				)
				);
		$this->debug($json, $result);
	}
	
	public function testDeleteGroupNotOwner() {
		$this->description = "This test case validates the scenario when a user delete a group that he is not the owner.";
		$this->do_login();
		$this->loadFixtures('User', 'UserGroup', 'UserGroupMapping');
		$data = array('token' => $this->token, 'id' => 2);
		$json = json_encode($data);
		$result = $this->testAction(
				'/v2/groups',
				array(
						'return' => 'contents',
						'data' => $json,
						'method' => 'delete'
				)
				);
		$this->debug($json, $result);
	}
	
	public function testDeleteGroup() {
		$this->description = "This test case validates the scenario when a user delete a group.";
		$this->do_login();
		$this->loadFixtures('User', 'UserGroup', 'UserGroupMapping');
		$data = array('token' => $this->token, 'id' => 4);
		$json = json_encode($data);
		$result = $this->testAction(
				'/v2/groups',
				array(
						'return' => 'contents',
						'data' => $json,
						'method' => 'delete'
				)
				);
		$this->debug($json, $result);
	}
	
	public function testUpdateGroup() {
		$this->description = "This test case validates the scenario when a user update a group's profile.";
		$this->do_login();
		$this->loadFixtures('User', 'UserGroup', 'UserGroupMapping');
		$data = array('token' => $this->token, 'label' => 'Soccer Daddy', 'id' => 4);
		$json = json_encode($data);
		$result = $this->testAction(
				'/v2/groups',
				array(
						'return' => 'contents',
						'data' => $json,
						'method' => 'put'
				)
				);
		$this->debug($json, $result);
	}
	
	public function testOwnerListsGroups() {
		echo("<h3>1) 'Groups' Screen</h3><img src='https://s3.invisionapp-cdn.com/storage.invisionapp.com/screens/files/144522943.png?x-amz-meta-ck=4bd8200ac91356d2488c0a3a424f1e59&response-cache-control=max-age%3D2419200&x-amz-meta-iv=1&AWSAccessKeyId=AKIAJFUMDU3L6GTLUDYA&Expires=1462075200&Signature=cjX6vJtcKwK4A5b2rBgI57oj7xQ%3D' width='200' height='600'>");
		$this->description = "This test case validates the scenario when a user lists all of his/her groups.";
		$this->do_login();
		$this->loadFixtures('User', 'UserGroup', 'UserGroupMapping', 'UserConnection');
		$result = $this->testAction(
			$this->addToken('/v2/groups'),
			array(
				'return' => 'contents',
				'data' => array('token' => $this->token),
				'method' => 'get'
			)
		);
		$this->debug("", $result);
	}
	
	public function testUserJoinsGroup() {
		$this->description = "This test case validates the scenario when a user makes a request to join a shared or " .
				"vendor group.";
		$this->do_login();
		$this->loadFixtures('User', 'UserGroup', 'UserGroupMapping');
		$data = '{"status": 3, "token": "' . $this->token . '"}';
		$result = $this->testAction(
			'/v2/member/group/2',
			array(
				'return' => 'contents',
				'data' => $data,
				'method' => 'post'
			)
		);
		$this->debug($data, $result);
	}
	
	public function testUserJoinsGroupUsingCode() {
		$this->description = "This test case validates the scenario when a user makes a request to join a shared or " .
				"vendor group using the code for that group.";
		$this->do_login();
		$this->loadFixtures('User', 'UserGroup', 'UserGroupMapping');
		$data = '{"status": 3, "token": "' . $this->token . '"}';
		$result = $this->testAction(
				'/v2/member/group/Karate4Kid',
				array(
						'return' => 'contents',
						'data' => $data,
						'method' => 'post'
				)
				);
		$this->debug($data, $result);
	}
	
	public function testUserHidesGroup() {
		$this->do_login();
		$this->loadFixtures('User', 'UserGroup', 'UserGroupMapping');
		$data = '{"status": "hide", "token": "' . $this->token . '"}';
		$result = $this->testAction(
			'/v2/member/group/2',
			array(
				'return' => 'contents',
				'data' => $data,
				'method' => 'delete'
			)
		);
		$this->debug($data, $result);		
	}
	
	public function testUserTerminatesMembership() {
		$this->do_login("email_1@gmail.com", "password_1");
		$this->loadFixtures('User', 'UserGroup', 'UserGroupMapping');
		$data = '{"token": "' . $this->token . '"}';
		$result = $this->testAction(
				'/v2/member/group/2',
				array(
						'return' => 'contents',
						'data' => $data,
						'method' => 'delete'
				)
				);
		$this->debug($data, $result);
	}
	
	public function testOwnerTerminatesMembership() {
		$this->do_login("email_1@gmail.com", "password_1");
		$this->loadFixtures('User', 'UserGroup', 'UserGroupMapping');
		$data = '{"token": "' . $this->token . '"}';
		$result = $this->testAction(
				'/v2/member/group/3',
				array(
						'return' => 'contents',
						'data' => $data,
						'method' => 'delete'
				)
				);
		$this->debug($data, $result);
	}
	
	public function testUserDeclinesInvitationToJoinGroup() {
		$this->do_login();
		$this->loadFixtures('User', 'UserGroup', 'UserGroupMapping');
		$data = '{"status": 5, "token": "' . $this->token . '"}';
		$result = $this->testAction(
			'/v2/member/group/2',
			array(
				'return' => 'contents',
				'data' => $data,
				'method' => 'put'
			)
		);
		$this->debug($data, $result);
	}
	
	public function testUserApprovesInvitationToJoinGroup() {
		$this->do_login();
		$this->loadFixtures('User', 'UserGroup', 'UserGroupMapping');
		$data = '{"status": 1, "token": "' . $this->token . '"}';
		$result = $this->testAction(
			'/v2/member/group/2',
			array(
				'return' => 'contents',
				'data' => $data,
				'method' => 'put'
			)
		);
		$this->debug($data, $result);		
	}
	
	public function testOwnerListsMembers() {
		echo("<h3>2) 'Trusted' Group</h3><img src='https://s3.invisionapp-cdn.com/storage.invisionapp.com/screens/files/140703684.png?x-amz-meta-ck=4bd8200ac91356d2488c0a3a424f1e59&response-cache-control=max-age%3D2419200&x-amz-meta-iv=9&AWSAccessKeyId=AKIAJFUMDU3L6GTLUDYA&Expires=1462075200&Signature=0H14lyKdZ7YTb4mZ8Vr3sjWqSgw%3D' width='200' height='500'>");
		$this->do_login();
		$this->loadFixtures('User', 'UserGroup', 'UserGroupMapping', 'UserImportedContact');
		$result = $this->testAction(
			$this->addToken('/v2/group/3/members'),	
			array(
				'return' => 'contents',
				'data' => array('token' => $this->token),
				'method' => 'get'
			)
		);
		$this->debug("", $result);		
	}
	
	public function testOwnerDeletedTrustedMember() {
		$this->do_login();
		$this->loadFixtures('User', 'UserGroup', 'UserGroupMapping', 'UserImportedContact');
		$data = '{"id": 4, "token": "' . $this->token . '"}';
		$result = $this->testAction(
			'/v2/group/3/members',
			array(
				'return' => 'contents',
				'data' => $data,
				'method' => 'delete'
			)
		);
		$this->debug("", $result);		
	}
	
	public function testOwnerDeletedInvalidUser() {
		$this->do_login();
		$this->loadFixtures('User', 'UserGroup', 'UserGroupMapping', 'UserImportedContact');
		$data = '{"id": 999, "token": "' . $this->token . '"}';
		$result = $this->testAction(
			'/v2/group/3/members',
			array(
				'return' => 'contents',
				'data' => $data,
				'method' => 'delete'
			)
		);
		$this->debug("", $result);
		$json = json_decode($result, true);
		$this->assertEqual($json['result'], 'error', 'result code');
	}
	
	public function testOwnerDeletedNonMember() {
		$this->do_login();
		$this->loadFixtures('User', 'UserGroup', 'UserGroupMapping', 'UserImportedContact');
		$data = '{"id": 1, "token": "' . $this->token . '"}';
		$result = $this->testAction(
				'/v2/group/3/members',
				array(
						'return' => 'contents',
						'data' => $data,
						'method' => 'delete'
				)
				);
		$this->debug("", $result);
		$json = json_decode($result, true);
		$this->assertEqual($json['result'], 'error', 'result code');
	}
	
	public function testOwnerAddsUserToGroup() {
		$this->do_login();
		$this->loadFixtures('User', 'UserGroup', 'UserGroupMapping', 'UserImportedContact');
		$data = '{"is_user": 1, "friend_user_id": 1, "token": "' . $this->token . '"}';
		$result = $this->testAction(
			'/v2/group/3/members',
			array(
				'return' => 'contents',
				'data' => $data,
				'method' => 'post'
			)
		);
		$this->debug($data, $result);
		$json = json_decode($result, true);
		$this->assertEqual($json['result'], 'success', 'result code');		
	}
	
	public function testOwnerAddsNonUserToGroup() {
		$this->do_login();
		$this->loadFixtures('User', 'UserGroup', 'UserGroupMapping', 'UserImportedContact', 'UserInvite', 'EmailQueue');
		$data = '{"is_user": 0, "contact_id": 1, "token": "' . $this->token . '"}';
		$result = $this->testAction(
			'/v2/group/3/members',
			array(
				'return' => 'contents',
				'data' => $data,
				'method' => 'post'
			)
		);
		$this->debug($data, $result);
		$json = json_decode($result, true);
		$this->assertEqual($json['result'], 'success', 'result code');
	}
	
	public function testAddNewMember() {
		echo("<h3>3)Add New Member Screen</h3><img src='https://s3.invisionapp-cdn.com/storage.invisionapp.com/screens/files/144522947.png?x-amz-meta-ck=4bd8200ac91356d2488c0a3a424f1e59&response-cache-control=max-age%3D2419200&x-amz-meta-iv=2&AWSAccessKeyId=AKIAJFUMDU3L6GTLUDYA&Expires=1462075200&Signature=xSwG6MnzKuA%2FfD0hUmScotcMr8o%3D' width='200' height='400'>");
		$this->do_login();
		$this->loadFixtures('User', 'UserGroup', 'UserGroupMapping', 'UserImportedContact');
		$data = '{"first_name": "first_name_1", "last_name": "last_name_1", "email_1": "email_1", "token": "' . $this->token . '"}';
		$result = $this->testAction(
			'/v2/group/3/members',
			array(
				'return' => 'contents',
				'data' => $data,
				'method' => 'post'
			)
		);
		$this->debug($data, $result);
		$json = json_decode($result, true);
		$this->assertEqual($json['result'], 'success', 'result code');		
	}
	
	public function testMemberListsFromMemberView() {
		echo("<h3>4) Alan Azoff Group</h3><img src='https://s3.invisionapp-cdn.com/storage.invisionapp.com/screens/files/140715691.png?x-amz-meta-ck=4bd8200ac91356d2488c0a3a424f1e59&response-cache-control=max-age%3D2419200&x-amz-meta-iv=4&AWSAccessKeyId=AKIAJFUMDU3L6GTLUDYA&Expires=1462075200&Signature=dsWXNwWQYdmlyroP0%2FH%2BqZq3OUI%3D' width='200' height='500'>");
		$this->do_login();
		$this->loadFixtures('User', 'UserGroup', 'UserGroupMapping', 'UserImportedContact');
		$data = '{"first_name": "first_name_1", "last_name": "last_name_1", "email_1": "email_1"}';
		$result = $this->testAction(
			$this->addToken('/v2/member/group/2'),
			array(
					'return' => 'contents',
					'data' => array('token' => $this->token),
					'method' => 'get'
			)
		);
		$this->debug($data, $result);
		$json = json_decode($result, true);
		$this->assertEqual($json['result'], 'success', 'result code');
	}
	
	public function testSearchMembersWithinGroup() {
		$this->do_login();
		$this->loadFixtures('User', 'UserGroup', 'UserGroupMapping', 'UserImportedContact');
		$data = '{"searched_text": "name", "token": "' . $this->token . '"}';
		$result = $this->testAction(
			'/v2/member/group/2',
			array(
				'return' => 'contents',
				'data' => $data,
				'method' => 'options'
			)
		);
		$this->debug($data, $result);
		$json = json_decode($result, true);
		$this->assertEqual($json['result'], 'success', 'result code');		
	}
	
	public function testSearchMembersAcrossGroups() {
		$this->do_login();
		$this->loadFixtures('User', 'UserGroup', 'UserGroupMapping', 'UserImportedContact');
		$data = '{"searched_text": "name", "token": "' . $this->token . '"}';
		$result = $this->testAction(
			'/v2/members',
			array(
				'return' => 'contents',
				'data' => $data,
				'method' => 'options'
			)
		);
		$this->debug($data, $result);
		$json = json_decode($result, true);
		$this->assertEqual($json['result'], 'success', 'result code');		
		
	}
	
	public function testSearchAllUsers() {
		$this->do_login();
		$this->loadFixtures('User', 'UserGroup', 'UserGroupMapping', 'UserImportedContact', 'UserConnection');
		$data = '{"searched_text": "name", "all_users": 1, "token": "' . $this->token . '"}';
		$result = $this->testAction(
			'/v2/members',
			array(
				'return' => 'contents',
				'data' => $data,
				'method' => 'options'
			)
		);
		$this->debug($data, $result);
		$json = json_decode($result, true);
		$this->assertEqual($json['result'], 'success', 'result code');
	}

	
}