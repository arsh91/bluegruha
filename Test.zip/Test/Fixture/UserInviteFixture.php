<?php

class UserInviteFixture extends CakeTestFixture {
	public $import = array('table' => 'user_invites');
}