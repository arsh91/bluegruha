<?php

class VendorManagementFixture extends CakeTestFixture {
	public $import = 'VendorManagement';
	public $records = array(
		array(
				'id' => 1,
				'vendor_id' => 1,
				'first_name' => 'first_name_1',
				'last_name' => 'last_name_1',
				'created_ts' => '2016-01-01 00:00:00',
				'updated_ts' => '2016-12-31 00:00:00',
				'email' => 'email_1@gmail.com',
				'password' => '15c902eed922ac0d8c88eaec606ca5fc',
				'role' => 1,
				'status' => 1
		),
		array(
				'id' => 2,
				'vendor_id' => 2,
				'first_name' => 'first_name_2',
				'last_name' => 'last_name_2',
				'created_ts' => '2016-01-01 00:00:00',
				'updated_ts' => '2016-12-31 00:00:00',
				'email' => 'email_2@gmail.com',
				'password' => '02388d293ef9d46363d601629d200c1d',
				'role' => 1,
				'status' => 1
		),
	);
}