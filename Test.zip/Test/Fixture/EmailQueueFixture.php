<?php

class EmailQueueFixture extends CakeTestFixture {
	public $import = array('table' => 'email_queues');
}