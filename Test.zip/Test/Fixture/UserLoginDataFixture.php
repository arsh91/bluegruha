<?php

class UserLoginDataFixture extends CakeTestFixture {
	public $import = array('table' => 'user_login_data');
}