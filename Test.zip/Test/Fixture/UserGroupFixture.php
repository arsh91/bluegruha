<?php

class UserGroupFixture extends CakeTestFixture {
	public $import = 'UserGroup';
	public $records = array(
		array(
			'id' => 1,
			'label' => 'VendorController Test',
			'description' => 'Group used by unit testing to test Vendor controller',
			'owner_user_id' => '1',
			'created_ts' => '2016-01-01 00:00:00',
			'updated_ts' => '2016-12-31 00:00:00',
			'group_code' => 'A1',
			'group_type' => 3,
			'status' => 1
		),
		array(
			'id' => 2,
			'label' => 'VendorController Test',
			'description' => 'Group used by unit testing to test Vendor API controller',
			'owner_user_id' => '1',
			'created_ts' => '2016-01-01 00:00:00',
			'updated_ts' => '2016-12-31 00:00:00',
			'group_code' => 'KARATE4KID',
			'group_type' => 3,
			'status' => 1
		),
		array(
			'id' => 3,
			'label' => 'Trusted Group',
			'description' => 'Trusted Group to test Group API controller',
			'owner_user_id' => '2',
			'created_ts' => '2016-01-01 00:00:00',
			'updated_ts' => '2016-12-31 00:00:00',
			'group_code' => 'A3',
			'group_type' => 1,
			'status' => 1
		),
		array(
			'id' => 4,
			'label' => 'Shared Group Test',
			'description' => 'Shared Group to test Group API controller',
			'owner_user_id' => '2',
			'created_ts' => '2016-01-01 00:00:00',
			'updated_ts' => '2016-12-31 00:00:00',
			'group_code' => 'A4',
			'group_type' => 2,
			'status' => 1
		)
	);
}