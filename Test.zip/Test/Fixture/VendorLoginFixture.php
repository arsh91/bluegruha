<?php

class VendorLoginFixture extends CakeTestFixture {
	public $import = 'VendorLogin';
}