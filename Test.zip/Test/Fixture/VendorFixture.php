<?php

class VendorFixture extends CakeTestFixture {
	public $import = 'Vendor';
	public $records = array(
		array(
				'id' => 1,
				'first_name' => 'first_name_1',
				'last_name' => 'last_name_1',
				'privacy' => 'privacy_1',
				'about_us' => 'about_us_1',
				'legal' => 'legal_1',
				'terms_conditions' => 'terms_conditions_1',
				'created_ts' => '2016-01-01 00:00:00',
				'updated_ts' => '2016-12-31 00:00:00',
				'email' => 'email_1@gmail.com',
				'phoneno' => 'phoneno_1',
				'address' => 'address_1',
				'vendor_user_id' => 1
		),
		array(
				'id' => 2,
				'first_name' => 'first_name_2',
				'last_name' => 'last_name_2',
				'privacy' => 'privacy_1',
				'about_us' => 'about_us_1',
				'legal' => 'legal_1',
				'terms_conditions' => 'terms_conditions_1',
				'created_ts' => '2016-01-01 00:00:00',
				'updated_ts' => '2016-12-31 00:00:00',
				'email' => 'email_2@gmail.com',
				'phoneno' => 'phoneno_1',
				'address' => 'address_1',
				'vendor_user_id' => 2
		)
	);
}