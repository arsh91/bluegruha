<?php

App::uses('SocialiTestFixture', 'Test/Fixture');

class UserFixture extends SocialiTestFixture {
	public $import = 'User';
	public $records = array(
		array(
			'id' => 1,
			'first_name' => 'first_name_1',
			'last_name' => 'last_name_1',
			'email' => 'email_1',	
			'status' => 1
		),
		array(
			'id' => 2,
			'first_name' => 'first_name_2',
			'last_name' => 'last_name_2',
			'email' => 'email_2',
			'status' => 1
		),
		array(
			'id' => 3,
			'first_name' => 'first_name_3',
			'last_name' => 'last_name_3',
			'email' => 'email_3',
			'status' => 1
		),		
		array(
			'id' => 4,
			'first_name' => 'first_name_x',
			'last_name' => 'last_name_x',
			'email' => 'email_4',
			'status' => 1
		),
		array(
			'id' => 5,
			'first_name' => 'first_name_y',
			'last_name' => 'last_name_5',
			'email' => 'email_5',
			'status' => 1
		),
	);
}