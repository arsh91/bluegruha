<?php

App::uses('SocialiTestFixture', 'Test/Fixture');

class UserImportedContactFixture extends SocialiTestFixture {
	public $import = 'UserImportedContact';
	public $records = array(
		array(
			"id" => 1,
			"first_name" => "contact_first_1",
			"last_name" => "contact_last_1",
			"email_1" => "contact_1@gmail.com",
			"phone_1" => "111111111"
		)
	);
}