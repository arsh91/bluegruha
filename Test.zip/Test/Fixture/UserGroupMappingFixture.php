<?php

App::uses('SocialiTestFixture', 'Test/Fixture');

class UserGroupMappingFixture extends SocialiTestFixture {
	public $import = 'UserGroupMapping';
	public $records = array(
		array(
			'friend_user_id' => '2',
			'group_id' => 1,
			'status' => MemberStatusEnum::VENDOR_INVITED,
			'created_ts' => '2016-01-01 00:00:00',
			'updated_ts' => '2016-01-01 00:00:00',
			'owner_user_id' => 1,
			'contact_id' => 0
		),
		array(
			'friend_user_id' => '2',
			'group_id' => 2,
			'status' => MemberStatusEnum::VENDOR_INVITED,
			'created_ts' => '2016-01-01 00:00:00',
			'updated_ts' => '2016-01-01 00:00:00',
			'owner_user_id' => 1,
			'contact_id' => 0
		),
		array(
			'friend_user_id' => '3',
			'group_id' => 2,
			'status' => MemberStatusEnum::ACTIVE,
			'created_ts' => '2016-01-01 00:00:00',
			'updated_ts' => '2016-01-01 00:00:00',
			'owner_user_id' => 1,
			'contact_id' => 0
		),
		array(
			'friend_user_id' => '2',
			'group_id' => 3,
			'status' => MemberStatusEnum::ACTIVE,
			'created_ts' => '2016-01-01 00:00:00',
			'updated_ts' => '2016-01-01 00:00:00',
			'owner_user_id' => 2,
			'contact_id' => 0
		),
		array(
			'friend_user_id' => '3',
			'group_id' => 3,
			'status' => MemberStatusEnum::ACTIVE,
			'created_ts' => '2016-01-01 00:00:00',
			'updated_ts' => '2016-01-01 00:00:00',
			'owner_user_id' => 2,
			'contact_id' => 0
		),
		array(
			'friend_user_id' => '2',
			'group_id' => 4,
			'status' => MemberStatusEnum::ACTIVE,
			'created_ts' => '2016-01-01 00:00:00',
			'updated_ts' => '2016-01-01 00:00:00',
			'owner_user_id' => 2,
			'contact_id' => 0
		),
		array(
			'friend_user_id' => '3',
			'group_id' => 4,
			'status' => MemberStatusEnum::ACTIVE,
			'created_ts' => '2016-01-01 00:00:00',
			'updated_ts' => '2016-01-01 00:00:00',
			'owner_user_id' => 2,
			'contact_id' => 0
		),
		array(
			'friend_user_id' => '4',
			'group_id' => 4,
			'status' => MemberStatusEnum::OWNER_INVITED,
			'created_ts' => '2016-01-01 00:00:00',
			'updated_ts' => '2016-01-01 00:00:00',
			'owner_user_id' => 2,
			'contact_id' => 0
		),
		array(
			'friend_user_id' => '5',
			'group_id' => 4,
			'status' => MemberStatusEnum::USER_REQUESTED,
			'created_ts' => '2016-01-01 00:00:00',
			'updated_ts' => '2016-01-01 00:00:00',
			'owner_user_id' => 2,
			'contact_id' => 0
		),
	);
}