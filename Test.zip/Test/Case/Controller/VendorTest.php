<?php

App::uses('UserGroupMapping', 'Model');

class VendorTest extends ControllerTestCase {
	public $fixtures = array('app.vendor', 'app.vendorManagement', 'app.vendorLogin', 'app.user', 'app.userGroup',
			'app.userGroupMapping', 'app.userImportedContact', 'app.userLoginData');
	public $autoFixtures = false;
	
	private $description = "";
	private static $imported_data = array();
	
	public function setUp() {
		parent::setUp();
		$this->UserGroupMapping = ClassRegistry::init('UserGroupMapping');
	}
	
	public function testLoginMissingEmail() {
		$this->loadFixtures('Vendor');
 		$_SERVER['CONTENT_TYPE'] = 'application/json';
 		$_SERVER['HTTP_ACCEPT'] = 'application/json';
		$data = '{"password": "???"}';
		$result = $this->testAction(
			'/v2/vendor/login',
			array (
					'return' => 'contents',
					'data' => $data,
					'method' => 'post'
			)
		);
		$this->description = "This test case validates the scenario when a user does a login without providing an email address.  " .
				"UI should do input validation instead of relying on API validation.";
		$this->debug($data, $result);
		$this->assertEqual($this->controller->response->statusCode(), 400, "Status Code");
		$json = json_decode($result, true);
		$this->assertArrayHasKey("result", $json, "'result'");
		$this->assertEqual($json["result"], "error");
		$this->assertArrayHasKey("message", $json, "message");
		
	}
	
	public function testLoginMissingPassword() {
		$this->loadFixtures('Vendor');
		$_SERVER['CONTENT_TYPE'] = 'application/json';
		$_SERVER['HTTP_ACCEPT'] = 'application/json';
		$data = '{"email": "???"}';
		$result = $this->testAction(
			'/v2/vendor/login',
			array (
					'return' => 'contents',
					'data' => $data,
					'method' => 'post'
			)
		);
		$this->description = "This test case validates the scenario when a user does a login without providing a password.  " .
			"UI should do input validation instead of relying on API validation.";
		$this->debug($data, $result);
		$this->assertEqual($this->controller->response->statusCode(), 400, "Status Code");
		$json = json_decode($result, true);
		$this->assertArrayHasKey("result", $json, "'result'");
		$this->assertEqual($json["result"], "error");
		$this->assertArrayHasKey("message", $json, "message");
	}
	
	public function testLoginInvalidEmail() {
		$this->loadFixtures('Vendor', 'VendorManagement');
		$_SERVER['CONTENT_TYPE'] = 'application/json';
		$_SERVER['HTTP_ACCEPT'] = 'application/json';
		$data = '{"email": "???", "password": "???"}';
		$result = $this->testAction(
			'/v2/vendor/login',
			array (
						'return' => 'contents',
						'data' => $data,
						'method' => 'post'
			)
		);
		$this->description = "This test case validates the scenario when a user does a login with an invalid email address.";
		$this->debug($data, $result);
		$this->assertEqual($this->controller->response->statusCode(), 401, "Status Code");
		$json = json_decode($result, true);
		$this->assertArrayHasKey("result", $json, "'result'");
		$this->assertEqual($json["result"], "error");
		$this->assertArrayHasKey("message", $json, "message");
	}
	
	public function testLoginInvalidPassword() {
		$this->loadFixtures('Vendor', 'VendorManagement');
		$_SERVER['CONTENT_TYPE'] = 'application/json';
		$_SERVER['HTTP_ACCEPT'] = 'application/json';
		$data = '{"email": "email_1@gmail.com", "password": "???"}';
		$result = $this->testAction(
			'/v2/vendor/login',
			array (
					'return' => 'contents',
					'data' => $data,
					'method' => 'post'
			)
		);
		$this->description = "This test case validates the scenario when a user does a login with an invalid password.";
		$this->debug($data, $result);
		$this->assertEqual($this->controller->response->statusCode(), 401, "Status Code");
		$json = json_decode($result, true);
		$this->assertArrayHasKey("result", $json, "'result'");
		$this->assertEqual($json["result"], "error");
		$this->assertArrayHasKey("message", $json, "message");
	}
	
	public function testLoginSuccess() {
		$this->loadFixtures('Vendor', 'VendorManagement', 'VendorLogin', 'UserLoginData');
		$_SERVER['CONTENT_TYPE'] = 'application/json';
		$_SERVER['HTTP_ACCEPT'] = 'application/json';
		$data = '{"email": "email_1@gmail.com", "password": "password_1"}';
		$result = $this->testAction(
				'/v2/vendor/login',
				array (
						'return' => 'contents',
						'data' => $data,
						'method' => 'post'
				)
		);
		$this->description = "This test case validates the scenario when a user does a login with correct email address and password.";
		$this->debug($data, $result);
		$this->assertEqual($this->controller->response->statusCode(), 200, "Status Code");
		$json = json_decode($result, true);
		$this->assertArrayHasKey("result", $json, "'result'");
		$this->assertEqual($json["result"], "success");
		$this->assertLoginResult($json);
		$this->assertEqual($this->controller->Session->check("Vendor.id"), true, "Session Vendor.id");
		$this->assertEqual($this->controller->Session->check("Vendor.token"), true, "Session Vendor.token");
		echo("Session Token:");
		pr($this->controller->Session->read("Vendor.token"));
	}
	
	public function testLoginEmailCaseSensitivity() {
		$this->loadFixtures('Vendor', 'VendorManagement', 'VendorLogin');
		$_SERVER['CONTENT_TYPE'] = 'application/json';
		$_SERVER['HTTP_ACCEPT'] = 'application/json';
		$data = '{"email": "EmAiL_1@GmAiL.COM", "password": "password_1"}';
		$result = $this->testAction(
			'/v2/vendor/login',
			array (
					'return' => 'contents',
					'data' => $data,
					'method' => 'post'
			)
		);
		$this->description = "This test case validates the scenario when a user does a login using an email address with both upper and lower case characters.";
		$this->debug($data, $result);
		$this->assertEqual($this->controller->response->statusCode(), 200, "Status Code");
		$json = json_decode($result, true);
		$this->assertArrayHasKey("result", $json, "'result'");
		$this->assertEqual($json["result"], "success");
		$this->assertLoginResult($json);
		$this->assertEqual($this->controller->Session->check("Vendor.id"), true, "Session Vendor.id");
		$this->assertEqual($this->controller->Session->check("Vendor.token"), true, "Session Vendor.token");
	}
	
	public function testLoginUsingForm() {
		$this->loadFixtures('Vendor', 'VendorManagement', 'VendorLogin');
		$_SERVER['CONTENT_TYPE'] = 'application/x-www-form-urlencoded';
		$_SERVER['HTTP_ACCEPT'] = 'application/json';
		$data = array('json' => '{"email": "email_1@gmail.com", "password": "password_1"}');
		$result = $this->testAction(
			'/v2/vendor/login',
			array (
					'return' => 'contents',
					'data' => $data,
					'method' => 'post'
			)
		);
		$this->description = "This test case validates the scenario when the login request was sent using FORM submit.  " .
				"The JSON data must be the value of the 'json' input parameter.";
		$this->debug($data, $result);
		$this->assertEqual($this->controller->response->statusCode(), 200, "Status Code");
		$json = json_decode($result, true);
		$this->assertArrayHasKey("result", $json, "'result'");
		$this->assertEqual($json["result"], "success");
		$this->assertLoginResult($json);
		$this->assertEqual($this->controller->Session->check("Vendor.id"), true, "Session Vendor.id");
		$this->assertEqual($this->controller->Session->check("Vendor.token"), true, "Session Vendor.token");		
	}
	
	public function testLogout() {
		$this->do_login();
		$result = $this->testAction(
			'/v2/vendor/logout',
			array (
					'return' => 'contents',
					'method' => 'post'
			)
		);
		$this->description = "This test case validates the scenario when a user does a logout.";
		$this->debug("", $result);
		$this->assertEqual($this->controller->response->statusCode(), 200, "Status Code");
		$json = json_decode($result, true);
		$this->assertArrayHasKey("result", $json, "'result'");
		$this->assertEqual($json["result"], "success");
		
		// Make sure that session data is cleared.
		$this->assertEqual($this->controller->Session->check("Vendor.id"), false, "Session Vendor.id");
		$this->assertEqual($this->controller->Session->check("Vendor.token"), false, "Session Vendor.token");		
	}
	
	public function testUnAuthorizedAccess() {
		$_SERVER['CONTENT_TYPE'] = 'application/json';
		$_SERVER['HTTP_ACCEPT'] = 'application/json';
		$result = $this->testAction(
			'/v2/vendor/logout',
			array (
					'return' => 'contents',
					'method' => 'get'
			)
		);
		$this->description = "This test case validates the unauthorized scenario when a request was made without doing a login first.";
		$this->debug("", $result);
		$this->assertEqual($this->controller->response->statusCode(), 401, "Status Code");
	}
	
	public function testChangePassword() {
		$login_info = $this->do_login();
		$this->assertLoginResult($login_info);
		$token = $login_info["data"]["token"];		
		$data = '{"token": "' . $token . '", "new_password": "new_password"}';
		$result = $this->testAction(
			'/v2/vendor/login',
			array (
				'return' => 'contents',
				'data' => $data,
				'method' => 'put'
			)
		);
		$this->description = "This test case validates the scenario when user does a password change.";
		$this->debug($data, $result);
		
		//$this->do_login("email_1@gmail.com", "new_password");
		
		$this->assertEqual($this->controller->response->statusCode(), 200, "Status Code");
		$json = json_decode($result, true);
		$this->assertArrayHasKey("result", $json, "'result'");
		$this->assertEqual($json["result"], "success");
		$this->assertEqual($this->controller->Session->check("Vendor.id"), true, "Session Vendor.id");
		$this->assertEqual($this->controller->Session->check("Vendor.token"), true, "Session Vendor.token");
	}
	
	public function testResetPassword() {
		$this->loadFixtures('Vendor', 'VendorManagement', 'VendorLogin');
		$_SERVER['CONTENT_TYPE'] = 'application/json';
		$_SERVER['HTTP_ACCEPT'] = 'application/json';		
		$data = '{"email": "email_1@gmail.com"}';
		$result = $this->testAction(
			'/v2/vendor/login',
			array (
				'return' => 'contents',
				'data' => $data,
				'method' => 'delete'
			)
		);
		$this->description = "This test case validates the scenario when user does a password reset.";
		$this->debug($data, $result);
	}
	
	public function testImport() {
		$this->do_login();
		$this->loadFixtures('User', 'UserGroup', 'UserGroupMapping');
		$_FILES = array('vcp_import' => array(
				'name' => 'vendors.xlsx',
				'tmp_name' => $_SERVER['DOCUMENT_ROOT'] . DS . 'vendors.xlsx',
				'type' => 'xls'
			)
		);
		$this->description = "This test case validates the scenario when a user imports the Customer list of a vendor. " .
			"This test case uses an Excel workbook 'vendors.xlsx'.  The workbook must be in the 'ROOT_DOCUMENT' directory.";
		$result = $this->testAction(
			'/v2/vendor',
			array (
					'return' => 'contents',
					'method' => 'post'
			)
		);
		$this->debug("", $result);
		$this->assertEqual($this->controller->response->statusCode(), 200, "Status Code");
		$json = json_decode($result, true);
		$this->assertArrayHasKey("result", $json, "'result'");
		$this->assertArrayHasKey("data", $json, "'data'");
		$this->assertEqual($json["result"], "success");
		VendorTest::$imported_data = $json["data"];
		$this->assertEqual(count($json["data"]), 8, "Number of records");
	}
	
	public function testSaveImport() {
		$this->do_login();
		$this->loadFixtures('User', 'UserGroup', 'UserGroupMapping', 'UserImportedContact');
		$data = json_encode(VendorTest::$imported_data);
		$this->description = "This test case validates the scenario when a user saves the imported data.";
		$result = $this->testAction(
			'/v2/vendor',
			array (
					'return' => 'contents',
					'data' => $data,
					'method' => 'post'
			)
		);
		$this->debug(json_encode(VendorTest::$imported_data, JSON_PRETTY_PRINT), $result);
	}
	
	public function testSecondImport() {
		$this->description = "This test case validates the scenario when a user does a second import.  " .
				"If the records have been imported previously, it won't be imported again.  Currently " .
				"the API won't do anything for records that were in the first import but not in the " .
				"second one.";
		
		// Do a login.
		$this->do_login();
		
		// Load golden data.
		$this->loadFixtures('User', 'UserGroup', 'UserGroupMapping');
		
		// Do a upload.
		$_FILES = array('vcp_import' => array(
				'name' => 'vendors.xlsx',
				'tmp_name' => $_SERVER['DOCUMENT_ROOT'] . DS . 'vendors.xlsx',
				'type' => 'xls'
			)
		);
		$result = $this->testAction(
			'/v2/vendor',
			array (
					'return' => 'contents',
					'method' => 'post'
			)
		);
		$this->assertEqual($this->controller->response->statusCode(), 200, "First Import Status Code");
		
		// Save the imported data.
		$json = json_decode($result, true);
		$data = json_encode($json['data']);
		$_FILES = array();
		$result = $this->testAction(
			'/v2/vendor',
			array (
					'return' => 'contents',
					'data' => $data,
					'method' => 'post'
			)
		);
		$this->assertEqual($this->controller->response->statusCode(), 200, "First Save Status Code");

		// Do a second upload.
		$_FILES = array('vcp_import' => array(
				'name' => 'vendors_2.xlsx',
				'tmp_name' => $_SERVER['DOCUMENT_ROOT'] . DS . 'vendors_2.xlsx',
				'type' => 'xls'
		)
		);
		$result = $this->testAction(
			'/v2/vendor',
			array (
					'return' => 'contents',
					'method' => 'post'
			)
		);
		$this->assertEqual($this->controller->response->statusCode(), 200, "Second Import Status Code");
		
		// Save the imported data.
		$json = json_decode($result, true);
		$data = json_encode($json['data']);
		$_FILES = array();
		$result = $this->testAction(
			'/v2/vendor',
			array (
					'return' => 'contents',
					'data' => $data,
					'method' => 'post'
			)
		);
		$this->assertEqual($this->controller->response->statusCode(), 200, "Status Code");
		$this->debug(json_encode($json['data'], JSON_PRETTY_PRINT), $result);
	}
	
	public function testAddNewCustomer() {
		$this->do_login();
		$this->loadFixtures('User', 'UserGroup', 'UserGroupMapping', 'UserImportedContact');
		$data = array(
        	array(
        		"First Name",
        		"Last Name",
        		"Email Address",
        		"Home Phone",
        		"Work Phone",
        		"Home Address",
        		"First Kid's First Name",
        		"First Kid's Last Name",
        		"Second Kid's First Name",
        		"Second Kid's Last Name",
        		"Third Kid's First Name",
        		"Third Kid's Last Name"
        	),
    		array(
        		"First_name_11",
        		"Last_name_11",
        		"Email_11",
        		"home_phone_11",
        		"work_phone_11",
        		"home_address_11",
        		"First_kid_first_name_11",
        		"First_kid_last_name_11",
        		"Second_kid_first_name_11",
        		"Second_kid_last_name_11",
        		"Third_kid_first_name_11",
        		"Third_kid_last_name_11"
    		)
		);
		$this->description = "This test case validates the scenario when a user adds a new Customer.";
		$result = $this->testAction(
			'/v2/vendor',
			array (
				'return' => 'contents',
				'data' => json_encode($data),
				'method' => 'post'
			)
		);
		$this->debug(json_encode($data, JSON_PRETTY_PRINT), $result);
	}
	
	public function testListMembers() {
		$this->description = "This test case validates the scenario when a user sends a request " .
				"to show a list of Customers.";
		$login_info = $this->do_login();
		$this->assertLoginResult($login_info);
		$this->loadFixtures('User', 'UserGroup', 'UserGroupMapping', 'UserImportedContact');
		$result = $this->testAction(
			'/v2/group/2/members',
			array (
				'return' => 'contents',
				'method' => 'get'
			)
		);
		$this->debug("", $result);
	}
	
	public function testListMembersUsingToken() {
		$this->description = "This test case validates the scenario when a user sends a request " .
				"to show a list of Customers using token based authentication instead of session " .
				"based authentication.";
		$login_info = $this->do_login();
		$this->assertLoginResult($login_info);
		$token = $login_info["data"]["token"];

		$this->loadFixtures('User', 'UserGroup', 'UserGroupMapping', 'UserImportedContact');
		$result = $this->testAction(
			"/v2/group/2/members/?token=$token",
			array (
					'return' => 'contents',
					'method' => 'get'
			)
		);
		$this->debug("", $result);
	}
	
	private function do_login($email="email_1@gmail.com", $password="password_1") {
		$this->loadFixtures('Vendor', 'VendorManagement', 'VendorLogin');
		$_SERVER['CONTENT_TYPE'] = 'application/json';
		$_SERVER['HTTP_ACCEPT'] = 'application/json';
		$data = '{"email": "' . $email . '", "password": "' . $password . '"}';
		$result = $this->testAction(
			'/v2/vendor/login',
			array (
				'return' => 'contents',
				'data' => $data,
				'method' => 'post'
			)
		);

		return json_decode($result, true);
	}
	
	private function assertLoginResult($json) {
		$this->assertArrayHasKey("message", $json, "message");
		$this->assertArrayHasKey("token", $json["data"], "token");

		$expected_msg = array(
				"first_name" => "first_name_1",
				"last_name" => "last_name_1",
				"privacy" => "privacy_1",
				"about_us" => "about_us_1",
				"legal" => "legal_1",
				"terms_conditions" => "terms_conditions_1",
				"phoneno" => "phoneno_1",
				"address" => "address_1",
				"user_first_name" => "first_name_1",
				"user_last_name" => "last_name_1",
				"vendor_user_id" => "1",
				"token" => $json['data']['token']           // don't check token.
		);
		$this->assertEquals($json["data"], $expected_msg, "message content");
	}
	
	private function debug($request, $response) {
		$trace = debug_backtrace();
		$caller = $trace[1]["function"];
		echo("<h3>Test Case: $caller</h3>");
		if ($this->description) {
			echo "Description:";
			echo("<div style='color: #000;background: #f0f0f0;padding: 15px;-moz-box-shadow: 1px 1px 2px rgba(0, 0, 0, 0.3);-webkit-box-shadow: 1px 1px 2px rgba(0, 0, 0, 0.3);box-shadow: 1px 1px 2px rgba(0, 0, 0, 0.3);'>");
			echo($this->description . "</div>");
		}
		echo("Request:<br>");
		$header = "";
		if (array_key_exists('CONTENT_TYPE', $_SERVER)) {
			$header .= "\nContent-Type: " . $_SERVER['CONTENT_TYPE'];
		}
		if (array_key_exists('HTTP_ACCEPT', $_SERVER)) {
			$header .= "\nAccept: " . $_SERVER['HTTP_ACCEPT'];
		}
		pr("Action: " . $_SERVER['REQUEST_METHOD'] .
				"\nEndPoint: " . $this->controller->request->here . "$header");
		if ($request) {
			pr($request);
		}
		echo("Response:<br>");
		pr($response);
		echo("Status Code:<br>");
		pr($this->controller->response->statusCode());
		$this->description = "";
	}
	
}